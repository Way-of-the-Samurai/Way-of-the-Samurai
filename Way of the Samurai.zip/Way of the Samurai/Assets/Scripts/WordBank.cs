﻿public class WordBank
{
    public string[] wordbank = { "up", "down", "left", "right" };
}
