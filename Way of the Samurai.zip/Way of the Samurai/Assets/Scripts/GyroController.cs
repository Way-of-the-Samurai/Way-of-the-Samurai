﻿using UnityEngine;

public class GyroController : MonoBehaviour
{
    Rigidbody rb;

    [SerializeField]
    private float gyroSensitivity = 1000f;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        Input.gyro.enabled = true;
    }

    private void FixedUpdate()
    {
        if (Input.gyro.enabled)
        {
            if (-Input.gyro.rotationRateUnbiased.y > -0.2f && -Input.gyro.rotationRateUnbiased.y < 0.2f)
            {
                //transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z);
                rb.velocity = Vector3.zero;
            }
            else
            {
                rb.velocity = new Vector3((-Input.gyro.rotationRateUnbiased.y * gyroSensitivity) * Time.deltaTime, 0, 0);
                //transform.Translate(-Input.gyro.rotationRateUnbiased.y, 0f, 0f);
            } 
        }
    }
}
