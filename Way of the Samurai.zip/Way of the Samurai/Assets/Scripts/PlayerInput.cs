﻿using UnityEngine;

public class PlayerInput : MonoBehaviour
{
    private Vector2 firstPressPos, secondPressPos, currentSwipe;

    public string SwipeDirection { get; private set; }

    private bool GetPlayerInput()
    {
        if (Input.GetMouseButtonDown(0))
        {
            //save began touch 2d point
            firstPressPos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        }
        if (Input.GetMouseButtonUp(0))
        {
            //save ended touch 2d point
            secondPressPos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);

            //create vector from the two points
            currentSwipe = new Vector2(secondPressPos.x - firstPressPos.x, secondPressPos.y - firstPressPos.y);

            //normalize the 2d vector
            currentSwipe.Normalize();

            return true;
        }

        return false;
    }

    public void SetCurrentSwipe(Vector2 swipe)
    {
        // Swipe upwards
        if (swipe.y > 0.3f && (swipe.x > -0.3f && swipe.x < 0.3f))
            SwipeDirection = "block";

        // Swipe down
        if (swipe.y < -0.3f && (swipe.x > -0.3f && swipe.x < 0.3f))
            SwipeDirection = "block";

        // Swipe left
        if ((swipe.y > -0.1f && (swipe.y < 0.1f) && swipe.x < -0.3f))
            SwipeDirection = "block";

        // Swipe right
        if ((swipe.y > -0.1f && swipe.y < 0.1f) && swipe.x > 0.3f)
            SwipeDirection = "block";

        // Swipe up left
        if (swipe.y > 0.3f && swipe.x < -0.3f)
            SwipeDirection = "attack";

        // Swipe up right
        if (swipe.y > 0.3f && swipe.x > 0.3f)
            SwipeDirection = "attack";

        // Swipe down left
        if (swipe.y < -0.3f && swipe.x < -0.3f)
            SwipeDirection = "attack";

        // Swipe down right
        if (swipe.y < -0.3f && swipe.x > 0.3f)
            SwipeDirection = "attack";
    }

    public string GetSwipeDirection()
    {
        if (GetPlayerInput())
        {
            SetCurrentSwipe(currentSwipe);
            return SwipeDirection;
        }
        else
            return "";
    }
}
