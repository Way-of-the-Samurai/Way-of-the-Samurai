﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyManager : MonoBehaviour
{
    public List<EnemyController> enemies, frontThree;

    public GameObject attackingEnemy;

    public GameObject cam;


    public GameObject[] warningImage;

    private void Update()
    {
        //
        if (!enemies[0].walking)
        {
            attackingEnemy = enemies[0].gameObject;
            SendWarning();
        }

        if (!enemies[1].walking)
        {
            attackingEnemy = enemies[1].gameObject;
            SendWarning();
        }

        if (!enemies[2].walking)
        {
            attackingEnemy = enemies[2].gameObject;
            SendWarning();
        }

        
        //}
    }

    private void SendWarning()
    {
        if (attackingEnemy.GetComponent<EnemyController>().warningSent)
        {
            if (cam.transform.position.x < attackingEnemy.gameObject.transform.position.x - 3f)
            {
                warningImage[0].SetActive(true);
                Debug.Log("hjfkdsa");
            }
            else if (cam.transform.position.x > attackingEnemy.gameObject.transform.position.x + 3f)
            {
                warningImage[1].SetActive(true);
                Debug.Log("Here");
            }
            else
            {
                warningImage[0].SetActive(false);
                warningImage[1].SetActive(false);
            }
        }

        if (attackingEnemy.GetComponent<EnemyController>().attacked)
        {
            Debug.Log("darkness my old friend");
            warningImage[0].SetActive(false);
            warningImage[1].SetActive(false);
            attackingEnemy.GetComponent<EnemyController>().ResetEnemy();

            attackingEnemy = null;


        }
    }
}
