﻿using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public float attackTimer, timerReset;
    public bool walking = true, attacked = false, dead;
    public bool warningSent = false;

    public Renderer meshRenderer;
    public Color attack, notAttack;
    //Material material;

    private void Awake()
    {
        timerReset = 2f;
        attackTimer = timerReset;

        meshRenderer = GetComponentInChildren<Renderer>();
        notAttack = meshRenderer.material.color;
    }

    private void Update()
    {
        if (!walking)
        {
            if (!attacked)
            {
                attackTimer -= Time.deltaTime;

                meshRenderer.material.color = attack; 

                //if (((attackTimer - 2f) <= 0) && !warningSent)
                //{
                //Debug.Log("Attack Warning");
                warningSent = true;
                //}
                if (attackTimer <= 0)
                {
                    //Debug.Log("Attacked");
                    attacked = true;
                    //attackTimer = timerReset;
                }
            }
        }
        else
        {
            meshRenderer.material.color = notAttack;
        }

    }

    public void TriggerWarning()
    {
        walking = false;
    }

    public void ResetEnemy()
    {
        walking = true;
        attacked = false;
        warningSent = false;
        attackTimer = timerReset;

    }
}
