﻿using UnityEngine;

public class DetectEnemy : MonoBehaviour
{
    private GameObject targetEnemy = null;
    
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            targetEnemy = other.gameObject;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            targetEnemy = null;
        }
    }

    public GameObject GetTargetEnemy()
    {
        return targetEnemy;
    }
}
