﻿using UnityEngine;

public class Player : MonoBehaviour
{
    private PlayerInput playerInput;
    private DetectEnemy detectEnemy;

    [SerializeField]
    public GameObject currentEnemy;
    public GameObject slashSprite;

    private void Awake()
    {
        playerInput = GetComponent<PlayerInput>();
        detectEnemy = FindObjectOfType<DetectEnemy>();
    }

    private void Update()
    {
        currentEnemy = detectEnemy.GetTargetEnemy();

        if (currentEnemy != null)
            if (playerInput.GetSwipeDirection() == "attack")
            {
                Debug.Log("Hello");
                slashSprite.SetActive(false);

                currentEnemy.SetActive(false);
            }
               // Debug.Log("Attacked Enemy");
    }
}
