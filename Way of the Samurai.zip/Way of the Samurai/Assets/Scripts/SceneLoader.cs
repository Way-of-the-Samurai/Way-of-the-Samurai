﻿using UnityEngine.SceneManagement;
using UnityEngine;

public class SceneLoader : MonoBehaviour
{
    private Camera cam;

    private void Awake()
    {
        cam = FindObjectOfType<Camera>();
    }

    public void SwitchPanels(int xPos)
    {
        cam.transform.position = new Vector3(xPos, cam.transform.position.y, cam.transform.position.z);
    }

    public void OpenClosePanel(GameObject panel)
    {
        panel.SetActive(!panel.activeSelf);
    }

    public void LoadLevel(string levelName)
    {
        SceneManager.LoadScene(levelName);
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}